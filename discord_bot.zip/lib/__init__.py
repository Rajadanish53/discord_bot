# Shared lib for calculator
